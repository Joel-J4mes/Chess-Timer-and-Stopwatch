package com.example.timerstopwatch;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Locale;

public class StopwatchFragment extends Fragment {

    private TextView timeView;
    private Button resetButton, lapButton;
    private CardView circularBackground;
    private RecyclerView lapRecyclerView;

    private long startTime = 0L;
    private long timeInMilliseconds = 0L;
    private long updatedTime = 0L;
    private long timeSwapBuff = 0L;
    private Handler customHandler = new Handler();

    private boolean isRunning = false;
    private ArrayList<String> lapTimes;
    private LapAdapter lapAdapter;

    // Runnable for notifications
    private Runnable notificationRunnable = new Runnable() {
        @Override
        public void run() {
            Intent serviceIntent = new Intent(getActivity(), NotificationService.class);
            getActivity().startService(serviceIntent);
            customHandler.postDelayed(this, 15000); // Repeat every 15 seconds
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_stopwatch, container, false);

        timeView = view.findViewById(R.id.timeView);
        resetButton = view.findViewById(R.id.resetButton);
        lapButton = view.findViewById(R.id.lapButton);
        circularBackground = view.findViewById(R.id.circularBackground);
        lapRecyclerView = view.findViewById(R.id.lapRecyclerView);

        lapTimes = new ArrayList<>();
        lapAdapter = new LapAdapter(lapTimes);
        lapRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        lapRecyclerView.setAdapter(lapAdapter);

        circularBackground.setOnClickListener(v -> toggleStopwatch());
        resetButton.setOnClickListener(v -> resetStopwatch());
        lapButton.setOnClickListener(v -> recordLap());

        return view;
    }

    private void toggleStopwatch() {
        if (!isRunning) {
            startTime = SystemClock.uptimeMillis();
            customHandler.postDelayed(updateTimerThread, 0);
            customHandler.postDelayed(notificationRunnable, 15000); // Start notification every 15 seconds
            isRunning = true;
            lapButton.setEnabled(true);
        } else {
            timeSwapBuff += timeInMilliseconds;
            customHandler.removeCallbacks(updateTimerThread);
            customHandler.removeCallbacks(notificationRunnable); // Stop notifications
            isRunning = false;
        }
    }

    private void resetStopwatch() {
        customHandler.removeCallbacks(updateTimerThread);
        customHandler.removeCallbacks(notificationRunnable); // Stop notifications
        startTime = 0L;
        timeInMilliseconds = 0L;
        updatedTime = 0L;
        timeSwapBuff = 0L;
        isRunning = false;
        updateTimerText();
        lapTimes.clear();
        lapAdapter.notifyDataSetChanged();
        lapButton.setEnabled(false);
    }

    private void recordLap() {
        if (isRunning) {
            String lapTime = timeView.getText().toString();
            lapTimes.add(0, "Lap " + (lapTimes.size() + 1) + ": " + lapTime);
            lapAdapter.notifyItemInserted(0);
            lapRecyclerView.scrollToPosition(0);
        }
    }

    private Runnable updateTimerThread = new Runnable() {
        public void run() {
            timeInMilliseconds = SystemClock.uptimeMillis() - startTime;
            updatedTime = timeSwapBuff + timeInMilliseconds;
            updateTimerText();
            customHandler.postDelayed(this, 0);
        }
    };

    private void updateTimerText() {
        int secs = (int) (updatedTime / 1000);
        int mins = secs / 60;
        secs = secs % 60;
        int milliseconds = (int) (updatedTime % 1000);
        timeView.setText(String.format(Locale.getDefault(), "%02d:%02d.%02d", mins, secs, milliseconds / 10));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        customHandler.removeCallbacks(updateTimerThread);
        customHandler.removeCallbacks(notificationRunnable); // Stop notifications
    }

    private static class LapAdapter extends RecyclerView.Adapter<LapAdapter.LapViewHolder> {
        private ArrayList<String> lapTimes;

        LapAdapter(ArrayList<String> lapTimes) {
            this.lapTimes = lapTimes;
        }

        @Override
        public LapViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_1, parent, false);
            return new LapViewHolder(view);
        }

        @Override
        public void onBindViewHolder(LapViewHolder holder, int position) {
            holder.lapTextView.setText(lapTimes.get(position));
        }

        @Override
        public int getItemCount() {
            return lapTimes.size();
        }

        static class LapViewHolder extends RecyclerView.ViewHolder {
            TextView lapTextView;

            LapViewHolder(View itemView) {
                super(itemView);
                lapTextView = itemView.findViewById(android.R.id.text1);
            }
        }
    }
}
