package com.example.timerstopwatch;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Switch;
import androidx.appcompat.app.AppCompatActivity;

public class Settings extends AppCompatActivity {

    private Switch soundSwitch;
    private Switch vibrationSwitch;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings); // Link to your XML layout file

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE);

        // Initialize Switches
        soundSwitch = findViewById(R.id.sound_switch);
        vibrationSwitch = findViewById(R.id.vibration_switch);

        // Load saved preferences
        boolean isSoundEnabled = sharedPreferences.getBoolean("SoundEnabled", true); // Default to true
        boolean isVibrationEnabled = sharedPreferences.getBoolean("VibrationEnabled", true); // Default to true

        // Set the switch states
        soundSwitch.setChecked(isSoundEnabled);
        vibrationSwitch.setChecked(isVibrationEnabled);

        // Set listeners to save the state when toggled
        soundSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Save the sound setting
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("SoundEnabled", isChecked);
                editor.apply();
            }
        });

        vibrationSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Save the vibration setting
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("VibrationEnabled", isChecked);
                editor.apply();
            }
        });

        RadioGroup timerModeGroup = findViewById(R.id.timer_mode_group);
        LinearLayout customTimerSettings = findViewById(R.id.custom_timer_settings);

        timerModeGroup.setOnCheckedChangeListener((group, checkedId) -> {
            String selectedMode;

            if (checkedId == R.id.blitz_mode) {
                selectedMode = "BLITZ";
                customTimerSettings.setVisibility(View.GONE);
            } else if (checkedId == R.id.bullet_mode) {
                selectedMode = "BULLET";
                customTimerSettings.setVisibility(View.GONE);
            } else if (checkedId == R.id.custom_mode) {
                selectedMode = "CUSTOM";
                customTimerSettings.setVisibility(View.VISIBLE);
            } else { // R.id.rapid_mode or default case
                selectedMode = "RAPID";
                customTimerSettings.setVisibility(View.GONE);
            }

            // Save the selected mode
            SharedPreferences prefs = getSharedPreferences("ChessTimerPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("SelectedTimerMode", selectedMode);
            editor.apply();
        });


    }
}
