package com.example.timerstopwatch;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ChessTimerFragment extends Fragment {

    private EditText player1EditText;
    private EditText player2EditText;
    private SharedPreferences sharedPreferences;

    public ChessTimerFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_chess_timer, container, false);

        // Initialize SharedPreferences
        sharedPreferences = getActivity().getSharedPreferences("AppSettings", getActivity().MODE_PRIVATE);

        // Find the EditText fields by their IDs
        player1EditText = view.findViewById(R.id.player1);
        player2EditText = view.findViewById(R.id.player2);

        // Find the button by its ID
        Button button = view.findViewById(R.id.button);

        // Set a click listener on the button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get player names from EditText fields
                String player1Name = player1EditText.getText().toString().trim();
                String player2Name = player2EditText.getText().toString().trim();

                // Check if player names are empty
                if (player1Name.isEmpty() || player2Name.isEmpty()) {
                    // Show a toast message if either name is empty
                    Toast.makeText(getActivity(), "Please enter both player names", Toast.LENGTH_SHORT).show();
                    return; // Exit the method to prevent further execution
                }

                // Store the player names in SharedPreferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("Player1Name", player1Name);
                editor.putString("Player2Name", player2Name);
                editor.apply(); // Save changes

                // Replace the current fragment with the new fragment
                Fragment newFragment = new TimerFragment();
                FragmentTransaction transaction = getParentFragmentManager().beginTransaction();

                // Replace the content and add the transaction to the back stack so the user can navigate back
                transaction.replace(R.id.fragment_container, newFragment);
                transaction.addToBackStack(null);

                // Commit the transaction
                transaction.commit();
            }
        });

        return view;
    }
}
