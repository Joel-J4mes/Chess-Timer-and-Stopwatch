package com.example.timerstopwatch;

public class Match {
    private String gameType;
    private String player1;
    private String player2;
    private String dateTime;
    private String winner;

    public Match(String gameType, String player1, String player2, String dateTime, String winner) {
        this.gameType = gameType;
        this.player1 = player1;
        this.player2 = player2;
        this.dateTime = dateTime;
        this.winner = winner;
    }

    public String getGameType() { return gameType; }
    public String getPlayer1() { return player1; }
    public String getPlayer2() { return player2; }
    public String getDateTime() { return dateTime; }
    public String getWinner() { return winner; }
}
