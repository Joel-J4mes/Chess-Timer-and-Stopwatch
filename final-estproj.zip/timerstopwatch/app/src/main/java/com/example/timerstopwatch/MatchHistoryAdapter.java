package com.example.timerstopwatch;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import java.util.List;



public class MatchHistoryAdapter extends RecyclerView.Adapter<MatchHistoryAdapter.MatchViewHolder> {
    private List<Match> matchList;

    public MatchHistoryAdapter(List<Match> matchList) {
        this.matchList = matchList;
    }

    @NonNull
    @Override
    public MatchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.match_item, parent, false);
        return new MatchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MatchViewHolder holder, int position) {
        Match match = matchList.get(position);
        holder.gameType.setText("Game Type: " + match.getGameType());
        holder.players.setText(match.getPlayer1() + " vs " + match.getPlayer2());
        holder.dateTime.setText("Date: " + match.getDateTime());
        holder.winner.setText("Winner: " + match.getWinner());
    }

    @Override
    public int getItemCount() {
        return matchList.size();
    }

    public static class MatchViewHolder extends RecyclerView.ViewHolder {
        TextView gameType, players, dateTime, winner;

        public MatchViewHolder(@NonNull View itemView) {
            super(itemView);
            gameType = itemView.findViewById(R.id.game_type);
            players = itemView.findViewById(R.id.player_names);
            dateTime = itemView.findViewById(R.id.match_date_time);
            winner = itemView.findViewById(R.id.match_result);
        }
    }
}
