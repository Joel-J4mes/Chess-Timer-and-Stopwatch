package com.example.timerstopwatch;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import androidx.fragment.app.Fragment;

public class TimerFragment extends Fragment {

    private TextView player1TimerView;
    private TextView player2TimerView;
    private TextView player1NameView;
    private TextView player2NameView;
    private TextView player1MoveCounterView;
    private TextView player2MoveCounterView;

    private Button pauseResumeButton;

    private Handler handler = new Handler();
    private Runnable timerRunnable;

    private long player1Time;
    private long player2Time;
    private int incrementTime;
    private boolean isPlayer1Turn = true;
    private boolean isGameActive = false;
    private boolean isPaused = true;  // Start as paused

    private int player1MoveCount = 0;
    private int player2MoveCount = 0;

    private MediaPlayer tapSound;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_timer_fragement, container, false);

        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("AppSettings", Context.MODE_PRIVATE);

        player1TimerView = view.findViewById(R.id.player1Timer);
        player2TimerView = view.findViewById(R.id.player2Timer);
        player1NameView = view.findViewById(R.id.player1Name);
        player2NameView = view.findViewById(R.id.player2Name);
        player1MoveCounterView = view.findViewById(R.id.player1MoveCounter);
        player2MoveCounterView = view.findViewById(R.id.player2MoveCounter);
        pauseResumeButton = view.findViewById(R.id.pauseResumeButton);

        // Set initial text for the button
        pauseResumeButton.setText("Start");

        String player1Name = sharedPreferences.getString("Player1Name", "Player 1");
        String player2Name = sharedPreferences.getString("Player2Name", "Player 2");

        player1NameView.setText(player1Name);
        player2NameView.setText(player2Name);

        loadTimerSettings();
        updateTimerUI();

        View topHalf = view.findViewById(R.id.topHalf);   // Player 1's side
        View bottomHalf = view.findViewById(R.id.bottomHalf); // Player 2's side

        topHalf.setOnClickListener(v -> handlePlayer1Tap());  // Handle Player 1 tap
        bottomHalf.setOnClickListener(v -> handlePlayer2Tap()); // Handle Player 2 tap

        // Pause/Resume button click listener
        pauseResumeButton.setOnClickListener(v -> toggleStartPauseResume());

        return view;
    }

    private void loadTimerSettings() {
        SharedPreferences prefs = getActivity().getSharedPreferences("ChessTimerPrefs", Context.MODE_PRIVATE);

        String selectedMode = prefs.getString("SelectedTimerMode", "RAPID"); // Default to Rapid mode

        switch (selectedMode) {
            case "BLITZ":
                player1Time = player2Time = 3 * 60 * 1000; // 3 minutes
                incrementTime = 2 * 1000; // 2 seconds
                break;
            case "BULLET":
                player1Time = player2Time = 1 * 60 * 1000; // 1 minute
                incrementTime = 0; // No increment
                break;
            case "CUSTOM":
                int minutes = prefs.getInt("CustomMinutes", 10);
                player1Time = player2Time = minutes * 60 * 1000;
                incrementTime = prefs.getInt("CustomIncrement", 0) * 1000;
                break;
            case "RAPID":
            default:
                player1Time = player2Time = 10 * 60 * 1000; // 10 minutes
                incrementTime = 0; // No increment
                break;
        }
    }

    private void handlePlayer1Tap() {
        if (!isPaused && !isPlayer1Turn) {  // Player 1 can only tap when it's Player 2's turn
            switchTurn();
        }
    }

    private void handlePlayer2Tap() {
        if (!isPaused && isPlayer1Turn) {  // Player 2 can only tap when it's Player 1's turn
            switchTurn();
        }
    }

    private void switchTurn() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("AppSettings", Context.MODE_PRIVATE);

        boolean isSoundEnabled = sharedPreferences.getBoolean("SoundEnabled", true);
        boolean isVibrationEnabled = sharedPreferences.getBoolean("VibrationEnabled", true);

        if (isSoundEnabled) {
            playSound();
        }

        if (isVibrationEnabled) {
            vibrate();
        }

        if (!isGameActive) {
            isGameActive = true;
            startTimer();
        } else {
            addMoveAndSwitchTurn(); // Increment move counter as soon as the turn switches
            addIncrementTime();
        }

        updateTimerUI();
    }

    private void addMoveAndSwitchTurn() {
        if (isPlayer1Turn) {
            player1MoveCount++;
            player1MoveCounterView.setText(String.valueOf(player1MoveCount)); // Update the UI for Player 1
        } else {
            player2MoveCount++;
            player2MoveCounterView.setText(String.valueOf(player2MoveCount)); // Update the UI for Player 2
        }
        isPlayer1Turn = !isPlayer1Turn;  // Switch turns
    }

    private void addIncrementTime() {
        if (isPlayer1Turn) {
            player1Time += incrementTime;
        } else {
            player2Time += incrementTime;
        }
    }

    private void playSound() {
        if (tapSound == null) {
            tapSound = MediaPlayer.create(getActivity(), R.raw.tap);
        }
        tapSound.start();

        tapSound.setOnCompletionListener(mp -> {
            mp.release();
            tapSound = null;
        });
    }

    private void vibrate() {
        Vibrator vibrator = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(200); // Vibrate for 200 milliseconds
        }
    }

    private void updateTimerUI() {
        player1TimerView.setText(formatTime(player1Time));
        player2TimerView.setText(formatTime(player2Time));

        player1TimerView.setTextColor(isPlayer1Turn ? getResources().getColor(android.R.color.holo_red_light) : getResources().getColor(android.R.color.black));
        player2TimerView.setTextColor(!isPlayer1Turn ? getResources().getColor(android.R.color.holo_red_light) : getResources().getColor(android.R.color.black));
    }

    private String formatTime(long time) {
        long minutes = (time / 1000) / 60;
        long seconds = (time / 1000) % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private void startTimer() {
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isPaused) {
                    if (isPlayer1Turn) {
                        player1Time -= 1000;
                        if (player1Time <= 0) {
                            endGame(false);
                            return;
                        }
                    } else {
                        player2Time -= 1000;
                        if (player2Time <= 0) {
                            endGame(true);
                            return;
                        }
                    }
                    updateTimerUI();
                }
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(timerRunnable);
    }

    private void endGame(boolean player1Wins) {
        isGameActive = false;
        handler.removeCallbacks(timerRunnable);

        // Get winner and loser names
        String winnerName = player1Wins ? player1NameView.getText().toString() : player2NameView.getText().toString();
        String loserName = !player1Wins ? player1NameView.getText().toString() : player2NameView.getText().toString();

        // Display winner message
        Toast.makeText(getActivity(), winnerName + " wins!", Toast.LENGTH_LONG).show();

        // Save match result
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("GameHistory", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Get current date and time
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d, yyyy - h:mm a");
        String currentDateTime = dateFormat.format(Calendar.getInstance().getTime());

        // Load previous matches from SharedPreferences (if any)
        Gson gson = new Gson();
        String json = sharedPreferences.getString("matchList", "");
        Type type = new TypeToken<List<Match>>(){}.getType();
        List<Match> matchList = gson.fromJson(json, type);

        if (matchList == null) {
            matchList = new ArrayList<>(); // Initialize if no previous matches
        }

        // Get selected timer mode from preferences
        SharedPreferences prefs = getActivity().getSharedPreferences("ChessTimerPrefs", Context.MODE_PRIVATE);
        String selectedMode = prefs.getString("SelectedTimerMode", "RAPID");

        // Create a new Match object
        Match newMatch = new Match(selectedMode, player1NameView.getText().toString(), player2NameView.getText().toString(), currentDateTime, winnerName);

        // Add the new match to the list
        matchList.add(newMatch);

        // Save updated match list back to SharedPreferences
        String updatedMatchListJson = gson.toJson(matchList);
        editor.putString("matchList", updatedMatchListJson);
        editor.apply(); // Save changes
    }

    // Pause/Resume functionality with initial "Start" state
    private void toggleStartPauseResume() {
        if (!isGameActive) {
            // Start the game
            isGameActive = true;
            isPaused = false;
            pauseResumeButton.setText("Pause"); // Change button text to "Pause"
            startTimer();
        } else {
            if (isPaused) {
                resumeTimer();
            } else {
                pauseTimer();
            }
        }
    }

    private void pauseTimer() {
        isPaused = true;
        pauseResumeButton.setText("Resume"); // Change button text to "Resume"
        handler.removeCallbacks(timerRunnable);
    }

    private void resumeTimer() {
        isPaused = false;
        pauseResumeButton.setText("Pause"); // Change button text back to "Pause"
        handler.post(timerRunnable); // Resume the timer from the last paused state
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (tapSound != null) {
            tapSound.release();
        }
    }
}
