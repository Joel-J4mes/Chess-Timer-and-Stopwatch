package com.example.timerstopwatch;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        loadSavedTheme(); // Load the saved theme before setting content view
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Set window insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize ViewPager2 and TabLayout
        ViewPager2 viewPager = findViewById(R.id.viewPager);
        TabLayout tabLayout = findViewById(R.id.tabLayout);

        // Set up the adapter
        ViewPagerAdapter adapter = new ViewPagerAdapter(this);
        viewPager.setAdapter(adapter);

        // Connect the TabLayout with ViewPager2
        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            switch (position) {
                case 0:
                    tab.setText("Chess Timer");
                    break;
                case 1:
                    tab.setText("Stopwatch");
                    break;
                case 2:
                    tab.setText("Match History");
            }
        }).attach();

        // Set up theme change buttons
        setupThemeButtons();
    }

    private void setupThemeButtons() {
        int[] buttonIds = {
                R.id.button_red_theme,
                R.id.button_blue_theme,
                R.id.button_green_theme,
                R.id.button_yellow_theme,
                R.id.button_purple_theme
        };

        for (int id : buttonIds) {
            Button button = findViewById(id);
            if (button != null) {
                button.setOnClickListener(this);
            }
        }
    }

    @Override
    public void onClick(View v) {
        String theme = "";
        int id = v.getId();
        if (id == R.id.button_red_theme) {
            theme = "ThemeRed";
        } else if (id == R.id.button_blue_theme) {
            theme = "ThemeBlue";
        } else if (id == R.id.button_green_theme) {
            theme = "ThemeGreen";
        } else if (id == R.id.button_yellow_theme) {
            theme = "ThemeYellow";
        } else if (id == R.id.button_purple_theme) {
            theme = "ThemePurple";
        }
        setAppTheme(theme);
    }

    private void setAppTheme(String theme) {
        SharedPreferences preferences = getSharedPreferences("AppSettings", MODE_PRIVATE);
        preferences.edit().putString("AppTheme", theme).apply();

        // Apply the theme immediately
        applyTheme(theme);

        // Recreate the activity to ensure all views are updated
        recreate();
    }

    private void applyTheme(String theme) {
        switch (theme) {
            case "ThemeRed":
                setTheme(R.style.ThemeRed);
                break;
            case "ThemeBlue":
                setTheme(R.style.ThemeBlue);
                break;
            case "ThemeGreen":
                setTheme(R.style.ThemeGreen);
                break;
            case "ThemeYellow":
                setTheme(R.style.ThemeYellow);
                break;
            case "ThemePurple":
                setTheme(R.style.ThemePurple);
                break;
            default:
                setTheme(R.style.AppTheme);
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(this, Settings.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadSavedTheme() {
        SharedPreferences preferences = getSharedPreferences("AppSettings", MODE_PRIVATE);
        String theme = preferences.getString("AppTheme", "AppTheme"); // Default to the base theme
        applyTheme(theme);
    }
}