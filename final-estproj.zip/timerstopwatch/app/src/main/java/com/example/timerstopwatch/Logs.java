package com.example.timerstopwatch;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class Logs extends Fragment {

    private RecyclerView matchHistoryRecycler;
    private MatchHistoryAdapter adapter;
    private List<Match> matchList;

    public Logs() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.match_history, container, false);

        matchHistoryRecycler = view.findViewById(R.id.match_history_recycler);
        matchHistoryRecycler.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize the adapter with an empty list
        matchList = new ArrayList<>();
        adapter = new MatchHistoryAdapter(matchList);
        matchHistoryRecycler.setAdapter(adapter);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadMatchHistory(); // Load data when the fragment becomes visible
    }

    private void loadMatchHistory() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("GameHistory", getContext().MODE_PRIVATE);
        String json = sharedPreferences.getString("matchList", "");
        Type type = new TypeToken<List<Match>>(){}.getType();

        // Load the match list from JSON
        Log.d("LogsFragment", "Loaded JSON: " + json);
        matchList = new Gson().fromJson(json, type);

        if (matchList == null) {
            matchList = new ArrayList<>(); // Initialize if no previous matches found
        }

        // Notify the adapter that the data has changed
        adapter = new MatchHistoryAdapter(matchList); // Update the adapter with new data
        matchHistoryRecycler.setAdapter(adapter); // Set the new adapter to the RecyclerView
    }
}
